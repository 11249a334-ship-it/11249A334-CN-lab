import socket
import threading

clients = []
client_names = {}


def broadcast(message, sender_socket=None):
    """Send a message to all connected clients except the sender."""
    for client in clients:
        if client != sender_socket:
            try:
                client.sendall(message.encode())
            except:
                pass


def handle_client(client_socket, client_address):
    # Receive client's name
    name = client_socket.recv(1024).decode()
    client_names[client_socket] = name

    print(f"{name} connected from {client_address}")

    broadcast(f"{name} joined the chat.", client_socket)

    while True:
        try:
            message = client_socket.recv(1024).decode()

            if not message:
                break

            print(message)
            broadcast(message, client_socket)

        except:
            break

    print(f"{name} disconnected.")

    clients.remove(client_socket)
    del client_names[client_socket]
    client_socket.close()

    broadcast(f"{name} left the chat.")


def chat_server():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)

    server_socket.bind(("localhost", 55555))
    server_socket.listen(5)

    print("Server listening on port 55555...")

    while True:
        client_socket, client_address = server_socket.accept()

        clients.append(client_socket)

        thread = threading.Thread(
            target=handle_client,
            args=(client_socket, client_address)
        )
        thread.daemon = True
        thread.start()


if __name__ == "__main__":
    chat_server()