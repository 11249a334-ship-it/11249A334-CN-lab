import socket
import threading


def receive_messages(client_socket):
    while True:
        try:
            message = client_socket.recv(1024).decode()

            if not message:
                print("Disconnected from server.")
                break

            print(message)

        except:
            break


def chat_client():
    client_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)

    try:
        client_socket.connect(("localhost", 55555))
        print("Connected to chat server.")

    except Exception as e:
        print("Unable to connect:", e)
        return

    name = input("Enter your name: ")

    # Send name to server
    client_socket.sendall(name.encode())

    receive_thread = threading.Thread(
        target=receive_messages,
        args=(client_socket,),
        daemon=True
    )
    receive_thread.start()

    while True:
        message = input()

        if message.lower() == "exit":
            break

        full_message = f"{name}: {message}"
        client_socket.sendall(full_message.encode())

    client_socket.close()


if __name__ == "__main__":
    chat_client()